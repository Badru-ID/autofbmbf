# USAGE
```
$ pkg update && pkg upgrade
$ pkg install git
$ pkg install python2
$ pkg install python
$ pip install requests
$ pip2 install mechanize
$ git clone https://github.com/Rizky-ID/autombf
$ cd autombf
$ python2 autombf.pyc
```
# NOTE
```
REMEMBER THE SIGNS ($) DO NOT FOLLOW ON TO TERMUX
```
# CAN BE USED IN:
```
Termux
```
# CONTACK
### FB : Rizky-ID
### GROUP : •HACKER•

# THANK YOU FOR USING MY TOOL
